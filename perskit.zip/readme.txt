simplyApps Press Kit
====================

This kit contains logo's and other materials that belong to simplyApps, these materials subject to copyright
law and may not be used without explicit permission of simplyApps and/or it's representatives.

For permission please contact:
management@simplyapps.nl


Defenitions:
 - simplyApps: Thomas Konings & Lieuwe Rooijakkers